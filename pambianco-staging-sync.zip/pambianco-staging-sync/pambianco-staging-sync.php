<?php
/**
 * Plugin Name: Pambianconews Staging Sync (Custom & Free)
 * Description: Plugin custom ed in-house per la sincronizzazione del database di Produzione su Staging Hetzner. Zero abbonamenti, zero dipendenze esterne.
 * Version: 2.0.0
 * Author: Team Pambianconews
 * Network: true
 */

if (!defined('ABSPATH')) exit;

define('PAMBIANCO_STAGING_HOST',    '188.34.207.45');
define('PAMBIANCO_STAGING_DB',      'pambianconews_staging');
define('PAMBIANCO_STAGING_DB_USER', 'pambianco');
define('PAMBIANCO_STAGING_DB_PASS', 'Staging2026!Password');
define('PAMBIANCO_STAGING_SECRET',  'PambiancoSync2026SecretKey!');

// Mapping domini produzione → staging per wp search-replace
define('PAMBIANCO_DOMAIN_MAP', serialize([
    'www.pambianconews.com'         => 'staging.pambianconews.com',
    'moda.pambianconews.com'        => 'moda.staging.pambianconews.com',
    'design.pambianconews.com'      => 'design.staging.pambianconews.com',
    'beauty.pambianconews.com'      => 'beauty.staging.pambianconews.com',
    'winefood.pambianconews.com'    => 'winefood.staging.pambianconews.com',
    'hotellerie.pambianconews.com'  => 'hotellerie.staging.pambianconews.com',
    'magazine.pambianconews.com'    => 'magazine.staging.pambianconews.com',
]));

class PambiancoStagingSync {

    public function __construct() {
        add_action('network_admin_menu',        [$this, 'add_network_menu']);
        add_action('wp_ajax_pambianco_trigger_sync', [$this, 'handle_sync_request']);
        // Endpoint ricevitore su staging (quando il plugin è attivo anche lì)
        add_action('wp_ajax_nopriv_pambianco_receive_dump', [$this, 'receive_dump']);
        add_action('wp_ajax_pambianco_receive_dump',        [$this, 'receive_dump']);
    }

    public function add_network_menu() {
        add_submenu_page(
            'settings.php',
            'Pambianconews Staging Sync',
            'Staging Sync (In-House)',
            'manage_network_options',
            'pambianco-staging-sync',
            [$this, 'render_admin_page']
        );
    }

    public function render_admin_page() {
        $prod_db   = DB_NAME;
        $prod_host = DB_HOST;
        $staging   = PAMBIANCO_STAGING_HOST;
        ?>
        <div class="wrap">
            <h1>🚀 Pambianconews Staging Sync (In-House)</h1>
            <p>Strumento proprietario per sincronizzare il database di Produzione (<strong><?php echo esc_html($prod_db); ?></strong>) sull'ambiente Staging Hetzner (<strong><?php echo esc_html($staging); ?></strong>).</p>

            <div class="card" style="max-width:640px;padding:20px;margin-top:20px;">
                <h2>🔄 Avvia Sincronizzazione Database</h2>
                <p>Il database di produzione verrà esportato e inviato su Staging. I domini vengono riscritti automaticamente. L'operazione può richiedere 1-3 minuti.</p>
                <p><strong style="color:#d63638;">⚠️ Attenzione:</strong> il database di Staging verrà sovrascritto completamente.</p>
                <button id="pambianco-sync-btn" class="button button-primary button-hero">Avvia Sincronizzazione Ora</button>
                <div id="sync-status-output" style="margin-top:15px;font-family:monospace;background:#f0f0f0;padding:12px;border-radius:4px;display:none;white-space:pre-wrap;"></div>
            </div>

            <div class="card" style="max-width:640px;padding:20px;margin-top:20px;">
                <h2>📋 Configurazione Corrente</h2>
                <table class="widefat" style="width:auto;">
                    <tr><td><strong>Produzione DB</strong></td><td><?php echo esc_html($prod_db); ?> @ <?php echo esc_html($prod_host); ?></td></tr>
                    <tr><td><strong>Staging Server</strong></td><td><?php echo esc_html($staging); ?></td></tr>
                    <tr><td><strong>Staging DB</strong></td><td><?php echo PAMBIANCO_STAGING_DB; ?></td></tr>
                </table>
            </div>
        </div>

        <script>
        jQuery(document.body).on('click', '#pambianco-sync-btn', function() {
            var btn    = jQuery(this);
            var output = jQuery('#sync-status-output');
            btn.prop('disabled', true).text('⏳ Sincronizzazione in corso...');
            output.show().html('⏳ Avvio esportazione database di produzione...\n');

            jQuery.post(ajaxurl, { action: 'pambianco_trigger_sync', _ajax_nonce: '<?php echo wp_create_nonce('pambianco_sync'); ?>' }, function(response) {
                btn.prop('disabled', false).text('Avvia Sincronizzazione Ora');
                if (response.success) {
                    output.append('\n✅ ' + response.data.message);
                } else {
                    output.append('\n❌ Errore: ' + response.data.message);
                }
            }).fail(function(xhr) {
                btn.prop('disabled', false).text('Avvia Sincronizzazione Ora');
                output.append('\n❌ Errore di rete: ' + xhr.status + ' ' + xhr.statusText);
            });
        });
        </script>
        <?php
    }

    /**
     * Gestione AJAX: esporta il DB produzione e lo invia allo staging via HTTP.
     */
    public function handle_sync_request() {
        if (!current_user_can('manage_network_options') || !check_ajax_referer('pambianco_sync', false, false)) {
            wp_send_json_error(['message' => 'Permessi non sufficienti o token non valido.']);
        }

        // 1. Crea dump SQL via PHP (senza dipendenze da exec/shell)
        $dump = $this->create_sql_dump();
        if (is_wp_error($dump)) {
            wp_send_json_error(['message' => $dump->get_error_message()]);
        }

        // 2. Applica search-replace domini prod → staging
        $domain_map = unserialize(PAMBIANCO_DOMAIN_MAP);
        foreach ($domain_map as $prod_domain => $staging_domain) {
            $dump = str_replace($prod_domain, $staging_domain, $dump);
        }

        // 3. Anonimizza email utenti
        $dump = preg_replace_callback(
            "/('[^']+@[^']+\.[^']+')/",
            function($m) { return "'staging_" . md5($m[1]) . "@pambianconews-staging.local'"; },
            $dump
        );

        // 4. Invia al ricevitore su Hetzner
        $receiver_url = 'https://' . PAMBIANCO_STAGING_HOST . '/pambianco-sync-receiver.php';
        $response = wp_remote_post($receiver_url, [
            'timeout'    => 180,
            'sslverify'  => false,
            'body'       => [
                'secret' => PAMBIANCO_STAGING_SECRET,
                'dump'   => base64_encode(gzcompress($dump, 6)),
                'db'     => PAMBIANCO_STAGING_DB,
                'dbuser' => PAMBIANCO_STAGING_DB_USER,
                'dbpass' => PAMBIANCO_STAGING_DB_PASS,
            ],
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error(['message' => 'Impossibile raggiungere Staging: ' . $response->get_error_message()]);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!empty($body['success'])) {
            wp_send_json_success(['message' => 'Database sincronizzato con successo su ' . PAMBIANCO_STAGING_HOST . '! Staging aggiornato alle ' . current_time('H:i') . '.']);
        } else {
            wp_send_json_error(['message' => $body['message'] ?? 'Risposta inattesa dal server Staging.']);
        }
    }

    /**
     * Genera un dump SQL completo usando solo PHP + wpdb (senza shell_exec).
     */
    private function create_sql_dump() {
        global $wpdb;

        $dump  = "-- Pambianconews Staging Sync Dump\n";
        $dump .= "-- Generato: " . date('Y-m-d H:i:s') . "\n";
        $dump .= "SET FOREIGN_KEY_CHECKS=0;\n";
        $dump .= "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n";
        $dump .= "SET NAMES utf8mb4;\n\n";

        $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
        if (!$tables) {
            return new WP_Error('no_tables', 'Nessuna tabella trovata nel database.');
        }

        foreach ($tables as $table_row) {
            $table = $table_row[0];

            // DROP + CREATE
            $create = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_N);
            $dump  .= "\nDROP TABLE IF EXISTS `{$table}`;\n";
            $dump  .= $create[1] . ";\n\n";

            // Dati
            $rows = $wpdb->get_results("SELECT * FROM `{$table}`", ARRAY_A);
            if (empty($rows)) continue;

            $columns = '`' . implode('`, `', array_keys($rows[0])) . '`';
            $chunk   = [];

            foreach ($rows as $row) {
                $values = array_map(function($v) use ($wpdb) {
                    if ($v === null) return 'NULL';
                    return "'" . esc_sql($v) . "'";
                }, array_values($row));
                $chunk[] = '(' . implode(', ', $values) . ')';

                // Inserisci a blocchi di 100 righe
                if (count($chunk) >= 100) {
                    $dump .= "INSERT INTO `{$table}` ({$columns}) VALUES\n" . implode(",\n", $chunk) . ";\n";
                    $chunk = [];
                }
            }
            if (!empty($chunk)) {
                $dump .= "INSERT INTO `{$table}` ({$columns}) VALUES\n" . implode(",\n", $chunk) . ";\n";
            }
        }

        $dump .= "\nSET FOREIGN_KEY_CHECKS=1;\n";
        return $dump;
    }
}

new PambiancoStagingSync();
